# VLSI Full Adder Project

## Description
1-bit Full Adder using Verilog HDL.

## Tools
- Icarus Verilog
- GTKWave

## Run
iverilog -o adder tb_adder.v adder.v
vvp adder
gtkwave wave.vcd
